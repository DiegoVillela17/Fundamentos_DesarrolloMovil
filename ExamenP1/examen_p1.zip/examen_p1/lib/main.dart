import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Reserva de Viaje',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: const ReservaViajeHome(), 
    );
  }
}

class ReservaViajeHome extends StatefulWidget {
  const ReservaViajeHome({super.key});

  @override
  State<ReservaViajeHome> createState() => _ReservaViajeHomeState();
}

class _ReservaViajeHomeState extends State<ReservaViajeHome> {
  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _correoController = TextEditingController();
  
  String _destinoSeleccionado = 'Playa';
  String _transporteSeleccionado = 'Avión';

  bool _hotelIncluido = false;
  bool _tourGuiado = false;
  bool _seguroViaje = false;
  bool _recibirNotificaciones = true;
  double _presupuesto = 3000.0;
  DateTime? _fechaViaje;

  void _limpiarDatos() {
    setState(() {
      _nombreController.clear();
      _correoController.clear();
      _destinoSeleccionado = 'Playa';
      _transporteSeleccionado = 'Avión';
      _hotelIncluido = false;
      _tourGuiado = false;
      _seguroViaje = false;
      _recibirNotificaciones = true;
      _presupuesto = 3000.0;
      _fechaViaje = null;
    });
  }

  @override
  void dispose() {
    _nombreController.dispose();
    _correoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.teal,
        title: const Text(
          'Reserva de Viaje',
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.cleaning_services, color: Colors.white),
            onPressed: _limpiarDatos,
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // SECCIÓN 1 - Información general
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12.0),
                  border: Border.all(color: Colors.teal.shade200),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.info_outline, color: Colors.teal),
                        const SizedBox(width: 8.0),
                        Text(
                          'Sección 1 - Información general',
                          style: TextStyle(
                            color: Colors.teal[800],
                            fontWeight: FontWeight.bold,
                            fontSize: 16.0,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8.0),
                    const Text(
                      'Completa tu reserva paso a paso',
                      style: TextStyle(color: Colors.grey, fontWeight: FontWeight.w500),
                    ),
                    const SizedBox(height: 8.0),
                    const Text(
                      'Llena tus datos, elige destino y confirma tu viaje.',
                      style: TextStyle(color: Colors.black87),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20.0),

              // SECCIÓN 2 - Datos del viajero
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12.0),
                  border: Border.all(color: Colors.green.shade200),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.person_outline, color: Colors.green),
                        const SizedBox(width: 8.0),
                        Text(
                          'Sección 2 - Datos del viajero',
                          style: TextStyle(
                            color: Colors.green[800],
                            fontWeight: FontWeight.bold,
                            fontSize: 16.0,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4.0),
                    const Text(
                      '¿Quién se va de viaje?',
                      style: TextStyle(color: Colors.grey),
                    ),
                    const SizedBox(height: 16.0),
                    TextField(
                      controller: _nombreController,
                      decoration: InputDecoration(
                        hintText: 'Ej: Ana Garcia',
                        labelText: 'Nombre completo',
                        prefixIcon: const Icon(Icons.person, color: Colors.green),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16.0),
                    TextField(
                      controller: _correoController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        hintText: 'Ej: ana@correo.com',
                        labelText: 'Correo electrónico',
                        prefixIcon: const Icon(Icons.email, color: Colors.green),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20.0),

              // SECCIÓN 3 - Destino y transporte
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12.0),
                  border: Border.all(color: Colors.orange.shade200),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.location_on_outlined, color: Colors.orange),
                        const SizedBox(width: 8.0),
                        Text(
                          'Sección 3 - Destino y transporte',
                          style: TextStyle(
                            color: Colors.orange[800],
                            fontWeight: FontWeight.bold,
                            fontSize: 16.0,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4.0),
                    const Text(
                      'Elige tu aventura',
                      style: TextStyle(color: Colors.grey),
                    ),
                    const SizedBox(height: 16.0),
                    Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                _destinoSeleccionado = 'Playa';
                              });
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Seleccionaste Playa')),
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 16.0),
                              decoration: BoxDecoration(
                                color: _destinoSeleccionado == 'Playa' ? Colors.blue.shade100 : Colors.grey.shade100,
                                borderRadius: BorderRadius.circular(8.0),
                                border: Border.all(
                                  color: _destinoSeleccionado == 'Playa' ? Colors.blue : Colors.transparent,
                                  width: 2.0,
                                ),
                              ),
                              child: Column(
                                children: const [
                                  Icon(Icons.beach_access, color: Colors.blue),
                                  SizedBox(height: 8.0),
                                  Text('Playa', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.blue)),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8.0),
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                _destinoSeleccionado = 'Ciudad';
                              });
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Seleccionaste Ciudad')),
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 16.0),
                              decoration: BoxDecoration(
                                color: _destinoSeleccionado == 'Ciudad' ? Colors.orange.shade100 : Colors.grey.shade100,
                                borderRadius: BorderRadius.circular(8.0),
                                border: Border.all(
                                  color: _destinoSeleccionado == 'Ciudad' ? Colors.orange : Colors.transparent,
                                  width: 2.0,
                                ),
                              ),
                              child: Column(
                                children: const [
                                  Icon(Icons.location_city, color: Colors.orange),
                                  SizedBox(height: 8.0),
                                  Text('Ciudad', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orange)),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8.0),
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                _destinoSeleccionado = 'Montaña';
                              });
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Seleccionaste Montaña')),
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 16.0),
                              decoration: BoxDecoration(
                                color: _destinoSeleccionado == 'Montaña' ? Colors.green.shade100 : Colors.grey.shade100,
                                borderRadius: BorderRadius.circular(8.0),
                                border: Border.all(
                                  color: _destinoSeleccionado == 'Montaña' ? Colors.green : Colors.transparent,
                                  width: 2.0,
                                ),
                              ),
                              child: Column(
                                children: const [
                                  Icon(Icons.landscape, color: Colors.green),
                                  SizedBox(height: 8.0),
                                  Text('Montaña', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20.0),
                    const Text(
                      'Transporte:',
                      style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black87),
                    ),
                    const SizedBox(height: 8.0),
                    DropdownButtonFormField<String>(
                      value: _transporteSeleccionado,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.directions_bus, color: Colors.orange),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      items: const [
                        DropdownMenuItem(value: 'Avión', child: Text('Avión')),
                        DropdownMenuItem(value: 'Autobús', child: Text('Autobús')),
                        DropdownMenuItem(value: 'Tren', child: Text('Tren')),
                        DropdownMenuItem(value: 'Barco', child: Text('Barco')),
                      ],
                      onChanged: (String? nuevoValor) {
                        setState(() {
                          _transporteSeleccionado = nuevoValor!;
                        });
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Transporte: $_transporteSeleccionado')),
                        );
                      },
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20.0),

              // SECCIÓN 4 - Extras y preferencias
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12.0),
                  border: Border.all(color: Colors.purple.shade200),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.tune, color: Colors.purple),
                        const SizedBox(width: 8.0),
                        Text(
                          'Sección 4 - Extras y preferencias',
                          style: TextStyle(
                            color: Colors.purple[800],
                            fontWeight: FontWeight.bold,
                            fontSize: 16.0,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4.0),
                    const Text(
                      'Personaliza tu experiencia',
                      style: TextStyle(color: Colors.grey),
                    ),
                    const SizedBox(height: 16.0),
                    
                    Container(
                      margin: const EdgeInsets.only(bottom: 12.0),
                      decoration: BoxDecoration(
                        color: _hotelIncluido ? Colors.purple.shade50 : Colors.grey.shade50,
                        borderRadius: BorderRadius.circular(8.0),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: CheckboxListTile(
                        title: const Text('Hotel incluido'),
                        subtitle: const Text('+ \$1200'),
                        secondary: const Icon(Icons.hotel, color: Colors.purple),
                        value: _hotelIncluido,
                        onChanged: (bool? valor) {
                          setState(() {
                            _hotelIncluido = valor ?? false;
                          });
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(_hotelIncluido ? 'Hotel incluido activado' : 'Hotel incluido desactivado')),
                          );
                        },
                      ),
                    ),

                    Container(
                      margin: const EdgeInsets.only(bottom: 12.0),
                      decoration: BoxDecoration(
                        color: _tourGuiado ? Colors.purple.shade50 : Colors.grey.shade50,
                        borderRadius: BorderRadius.circular(8.0),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: CheckboxListTile(
                        title: const Text('Tour guiado'),
                        subtitle: const Text('+ \$600'),
                        secondary: const Icon(Icons.tour, color: Colors.purple),
                        value: _tourGuiado,
                        onChanged: (bool? valor) {
                          setState(() {
                            _tourGuiado = valor ?? false;
                          });
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(_tourGuiado ? 'Tour guiado activado' : 'Tour guiado desactivado')),
                          );
                        },
                      ),
                    ),

                    Container(
                      margin: const EdgeInsets.only(bottom: 12.0),
                      decoration: BoxDecoration(
                        color: _seguroViaje ? Colors.purple.shade50 : Colors.grey.shade50,
                        borderRadius: BorderRadius.circular(8.0),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: CheckboxListTile(
                        title: const Text('Seguro de viaje'),
                        subtitle: const Text('+ \$400'),
                        secondary: const Icon(Icons.health_and_safety, color: Colors.purple),
                        value: _seguroViaje,
                        onChanged: (bool? valor) {
                          setState(() {
                            _seguroViaje = valor ?? false;
                          });
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(_seguroViaje ? 'Seguro de viaje activado' : 'Seguro de viaje desactivado')),
                          );
                        },
                      ),
                    ),

                    Container(
                      margin: const EdgeInsets.only(bottom: 16.0),
                      decoration: BoxDecoration(
                        color: Colors.purple.shade50.withOpacity(0.5),
                        borderRadius: BorderRadius.circular(8.0),
                        border: Border.all(color: Colors.purple.shade100),
                      ),
                      child: SwitchListTile(
                        title: const Text('Recibir notificaciones', style: TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text(_recibirNotificaciones ? 'Activadas' : 'Desactivadas'),
                        value: _recibirNotificaciones,
                        onChanged: (bool valor) {
                          setState(() {
                            _recibirNotificaciones = valor;
                          });
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(_recibirNotificaciones ? 'Notificaciones activadas' : 'Notificaciones desactivadas')),
                          );
                        },
                      ),
                    ),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Presupuesto:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0)),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 6.0),
                          decoration: BoxDecoration(
                            color: Colors.purple,
                            borderRadius: BorderRadius.circular(20.0),
                          ),
                          child: Text(
                            '\$${_presupuesto.toInt()}',
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                    Slider(
                      value: _presupuesto,
                      min: 500,
                      max: 10000,
                      divisions: 20,
                      activeColor: Colors.purple,
                      label: '\$${_presupuesto.toInt()}',
                      onChanged: (double valor) {
                        setState(() {
                          _presupuesto = valor;
                        });
                      },
                    ),

                    const SizedBox(height: 12.0),

                    InkWell(
                      onTap: () async {
                        DateTime? fechaSeleccionada = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(2026),
                          lastDate: DateTime(2030),
                        );
                        if (fechaSeleccionada != null) {
                          setState(() {
                            _fechaViaje = fechaSeleccionada;
                          });
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Fecha seleccionada con éxito')),
                          );
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.all(12.0),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8.0),
                          border: Border.all(color: Colors.grey.shade400),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.calendar_month, color: Colors.purple),
                            const SizedBox(width: 12.0),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('Fecha del viaje', style: TextStyle(color: Colors.grey, fontSize: 12.0)),
                                Text(
                                  _fechaViaje == null 
                                      ? 'Toca para elegir fecha' 
                                      : '${_fechaViaje!.day.toString().padLeft(2, '0')}/${_fechaViaje!.month.toString().padLeft(2, '0')}/${_fechaViaje!.year}',
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15.0),
                                ),
                              ],
                            ),
                            const Spacer(),
                            const Icon(Icons.chevron_right, color: Colors.grey),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20.0),

              // SECCIÓN 5 - Confirmar
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.teal.shade800,
                  borderRadius: BorderRadius.circular(12.0),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.check_circle_outline, color: Colors.white),
                        const SizedBox(width: 8.0),
                        Text(
                          'Sección 5 - Confirmar',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16.0,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4.0),
                    const Text(
                      'Revisa tus datos antes de despegar',
                      style: TextStyle(color: Colors.white70),
                    ),
                    const SizedBox(height: 16.0),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              foregroundColor: Colors.teal.shade800,
                              padding: const EdgeInsets.symmetric(vertical: 12.0),
                            ),
                            onPressed: () {
                              if (_nombreController.text.trim().isEmpty || 
                                  !_correoController.text.contains('@') || 
                                  _fechaViaje == null) {
                                showDialog(
                                  context: context,
                                  builder: (context) => AlertDialog(
                                    title: Row(
                                      children: const [
                                        Icon(Icons.error_outline, color: Colors.red),
                                        SizedBox(width: 8.0),
                                        Text('Faltan datos'),
                                      ],
                                    ),
                                    content: const Text('Completa nombre, correo válido (@) y selecciona la fecha del viaje.'),
                                    actions: [
                                      TextButton(
                                        onPressed: () => Navigator.pop(context),
                                        child: const Text('Entendido'),
                                      ),
                                    ],
                                  ),
                                );
                              } else {
                                showDialog(
                                  context: context,
                                  builder: (context) => AlertDialog(
                                    title: Row(
                                      children: const [
                                        Icon(Icons.receipt_long, color: Colors.teal),
                                        SizedBox(width: 8.0),
                                        Text('Resumen del Viaje'),
                                      ],
                                    ),
                                    content: SingleChildScrollView(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text('Nombre: ${_nombreController.text}'),
                                          Text('Correo: ${_correoController.text}'),
                                          Text('Destino: $_destinoSeleccionado'),
                                          Text('Transporte: $_transporteSeleccionado'),
                                          Text('Extras: ${_hotelIncluido ? "Hotel " : ""}${_tourGuiado ? "Tour " : ""}${_seguroViaje ? "Seguro" : ""}'),
                                          Text('Notificaciones: ${_recibirNotificaciones ? "Activadas" : "Desactivadas"}'),
                                          Text('Presupuesto: \$${_presupuesto.toInt()}'),
                                          Text('Fecha: ${_fechaViaje!.day.toString().padLeft(2, '0')}/${_fechaViaje!.month.toString().padLeft(2, '0')}/${_fechaViaje!.year}'),
                                        ],
                                      ),
                                    ),
                                    actions: [
                                      TextButton(
                                        onPressed: () => Navigator.pop(context),
                                        child: const Text('Cerrar'),
                                      ),
                                      ElevatedButton(
                                        style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white),
                                        onPressed: () {
                                          Navigator.pop(context);
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => PantallaBoleto(
                                                nombre: _nombreController.text,
                                                correo: _correoController.text,
                                                destino: _destinoSeleccionado,
                                                transporte: _transporteSeleccionado,
                                                hotel: _hotelIncluido,
                                                tour: _tourGuiado,
                                                seguro: _seguroViaje,
                                                notificaciones: _recibirNotificaciones,
                                                presupuesto: _presupuesto,
                                                fecha: '${_fechaViaje!.day.toString().padLeft(2, '0')}/${_fechaViaje!.month.toString().padLeft(2, '0')}/${_fechaViaje!.year}',
                                              ),
                                            ),
                                          );
                                        },
                                        child: const Text('Confirmar'),
                                      ),
                                    ],
                                  ),
                                );
                              }
                            },
                            icon: const Icon(Icons.remove_red_eye),
                            label: const Text('Ver Resumen'),
                          ),
                        ),
                        const SizedBox(width: 12.0),
                        Expanded(
                          child: ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.amber.shade700,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 12.0),
                            ),
                            onPressed: () {
                              if (_nombreController.text.trim().isEmpty || 
                                  !_correoController.text.contains('@') || 
                                  _fechaViaje == null) {
                                showDialog(
                                  context: context,
                                  builder: (context) => AlertDialog(
                                    title: const Text('Faltan datos'),
                                    content: const Text('Completa nombre, correo válido (@) y selecciona la fecha del viaje.'),
                                    actions: [
                                      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Entendido')),
                                    ],
                                  ),
                                );
                              } else {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => PantallaBoleto(
                                      nombre: _nombreController.text,
                                      correo: _correoController.text,
                                      destino: _destinoSeleccionado,
                                      transporte: _transporteSeleccionado,
                                      hotel: _hotelIncluido,
                                      tour: _tourGuiado,
                                      seguro: _seguroViaje,
                                      notificaciones: _recibirNotificaciones,
                                      presupuesto: _presupuesto,
                                      fecha: '${_fechaViaje!.day.toString().padLeft(2, '0')}/${_fechaViaje!.month.toString().padLeft(2, '0')}/${_fechaViaje!.year}',
                                    ),
                                  ),
                                );
                              }
                            },
                            icon: const Icon(Icons.check),
                            label: const Text('Confirmar'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PantallaBoleto extends StatelessWidget {
  final String nombre;
  final String correo;
  final String destino;
  final String transporte;
  final bool hotel;
  final bool tour;
  final bool seguro;
  final bool notificaciones;
  final double presupuesto;
  final String fecha;

  const PantallaBoleto({
    super.key,
    required this.nombre,
    required this.correo,
    required this.destino,
    required this.transporte,
    required this.hotel,
    required this.tour,
    required this.seguro,
    required this.notificaciones,
    required this.presupuesto,
    required this.fecha,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.teal,
        title: const Text('Mi Boleto', style: TextStyle(color: Colors.white)),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Card(
              elevation: 4.0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
              clipBehavior: Clip.antiAlias,
              child: Column(
                children: [
                  Container(
                    color: Colors.teal.shade700,
                    width: double.infinity,
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Icon(Icons.flight_takeoff, color: Colors.white),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 4.0),
                              decoration: BoxDecoration(
                                color: Colors.amber,
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              child: Text(fecha, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12.0)),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16.0),
                        Center(
                          child: Column(
                            children: [
                              Text(
                                '¡Buen viaje, $nombre!',
                                style: const TextStyle(color: Colors.white, fontSize: 20.0, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 4.0),
                              Text(
                                destino.toUpperCase(),
                                style: const TextStyle(color: Colors.white70, fontSize: 14.0, letterSpacing: 2.0),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        ListTile(
                          leading: const Icon(Icons.email, color: Colors.teal),
                          title: const Text('Correo', style: TextStyle(fontSize: 12.0, color: Colors.grey)),
                          subtitle: Text(correo, style: const TextStyle(fontWeight: FontWeight.bold)),
                        ),
                        const Divider(),
                        ListTile(
                          leading: const Icon(Icons.location_on, color: Colors.yellow),
                          title: const Text('Destino', style: TextStyle(fontSize: 12.0, color: Colors.grey)),
                          subtitle: Text(destino, style: const TextStyle(fontWeight: FontWeight.bold)),
                          trailing: Chip(label: Text(transporte)),
                        ),
                        const Divider(),
                        ListTile(
                          leading: const Icon(Icons.star, color: Colors.purple),
                          title: const Text('Extras', style: TextStyle(fontSize: 12.0, color: Colors.grey)),
                          subtitle: Text(
                            '${hotel ? "Hotel " : ""}${tour ? "Tour " : ""}${seguro ? "Seguro" : ""}' == '' 
                                ? 'Ninguno' 
                                : '${hotel ? "Hotel " : ""}${tour ? "Tour " : ""}${seguro ? "Seguro" : ""}',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                        const Divider(),
                        ListTile(
                          leading: const Icon(Icons.notifications, color: Colors.blue),
                          title: const Text('Notificaciones', style: TextStyle(fontSize: 12.0, color: Colors.grey)),
                          subtitle: Text(notificaciones ? 'Activadas' : 'Desactivadas', style: const TextStyle(fontWeight: FontWeight.bold)),
                          trailing: Text(
                            '\$${presupuesto.toInt()}',
                            style: const TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold, color: Colors.teal),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24.0),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal.shade800,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14.0),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0)),
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.arrow_back),
                label: const Text('Regresar y editar', style: TextStyle(fontSize: 16.0)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}